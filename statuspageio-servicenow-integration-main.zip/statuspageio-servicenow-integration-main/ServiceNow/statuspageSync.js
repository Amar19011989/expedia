var StatuspageSync = Class.create();

StatuspageSync.prototype = {
  initialize: function () {
    this.arrayUtil = new global.ArrayUtil();
    this.statuspageContent = new StatuspageContent();
    var _logLevels = gs.getProperty('x_expe2_statuspage.log_levels');
    this.logLevels = gs.nil(_logLevels) ? [] : _logLevels.split(',');
    this.maxRetryCount = 20;
    this.getNestedObject = function(nestedObj, path) {
        return path.split('.').reduce(function(obj, key) {
            return (obj && obj[key] !== 'undefined') ? obj[key] : undefined;
        }, nestedObj);
    };
    this.allIncidents = [];
    this.incidentsRetrieved = false;
    this.allComponents = [];
    this.componentsRetrieved = false;
    this.sleep = new global.SleepForScopedApp().sleep;
  },

  /**
   * Log if level is configured
   * @param {String} level log level (info, error, debug)
   * @param {String} msg log message
   */
  log: function(level, msg) {
    if (this.arrayUtil.contains(this.logLevels, level)) {
      gs[level](msg);
    }
  },

  /**
   * Get Statuspage Group
   * @param {String} groupId
   * @return {Object} statuspage Group Object
   */
  getStatuspageGroup: function (groupId) {
    var path = 'component-groups/' + groupId;
    var rest = new StatuspageRest();
    var response = rest.getREST(path);
    var status = response.getStatusCode() || -1;
    if (status == 200) {
      return JSON.parse(response.getBody());
    }
  },

  /**
   * Get Statuspage Groups
   * @return {Object} Map of statuspage Group Objects by Group Name
   */
  getStatuspageGroups: function () {
    var _all_groups = {};
    var path = 'component-groups';
    var rest = new StatuspageRest();
    var response = rest.getREST(path);
    var status = response.getStatusCode() || -1;
    if (status == 200) {
      JSON.parse(response.getBody()).forEach(function (group) {
        _all_groups[group.name] = group;
      });
      return _all_groups;
    }
  },

  /**
   * Get Statuspage Components
   * @return {Object} Map of statuspage Group Components by Group Name
   */
  getStatuspageComponents: function () {
    if (!this.componentsRetrieved){
      var raw_components = [];
      var components = [];
      var groups = {};
      var more = true;
      var page = 0;
      var rest = new StatuspageRest();
      while (more){
        var path = (page > 0) ? 'components?per_page=100&page=' + page : 'components?per_page=100';
        var response = rest.getREST(path);
        var status = response.getStatusCode() || -1;
        if (status == 200) {
          var response_object = JSON.parse(response.getBody());
          response_object.forEach(function (component) {
            raw_components.push(component);
          });
          if (response_object.length<100){
            more = false;
          } else {
            page = page + 1;
          }
        } else {
          throw "Failed to getStatuspageComponents";
        }
      }
      raw_components.forEach(function (component) {
        if (component.group) {
          groups[component.id] = component.name;
        } else {
          components.push(component);
        }
      });
      this.allComponents = [];
      for (var i = 0; i < components.length; i++) { 
        var _component = components[i];
        _component.group_name = groups[components[i].group_id];
        this.allComponents.push(_component);
      }
      this.componentsRetrieved = true;
    }
    return this.allComponents;
  },

  /**
   * Create Statuspage Group
   * @param {String} groupName 
   * @param {Array} componentId list of componentIds in group
   * @return {Object} statuspage Group Object
   */
  createStatuspageGroup: function (groupName, components) {
    var request = {
      component_group: {
        components: components,
        name: groupName
      }
    };
    var path = 'component-groups';
    var rest = new StatuspageRest();
    var response = rest.postREST(path, request);
    var status = response.getStatusCode() || -1;
    if (status == 204) {
      return JSON.parse(response.getBody());
    }
  },

  /**
   * Add Component to Statuspage Group
   * @param {String} componentId 
   * @param {String} groupId
   * @return {Object} statuspage Group Object
   */
  addComponentToStatuspageGroup: function (componentId, groupId) {
    var group = this.getStatuspageGroup(groupId);
    var components = group.components;
    components.push(componentId);
    var request = {
      component_group: {
        components: components,
        name: group.name
      }
    };
    var path = 'component-groups';
    var rest = new StatuspageRest();
    var response = rest.patchREST(path, request);
    var status = response.getStatusCode() || -1;
    if (status == 200) {
      return JSON.parse(response.getBody());
    }
  },

  /**
   * Create Statuspage Component
   * @param {String} componentId 
   * @param {String} groupId
   * @return {Object} statuspage Group Object
   */
  createStatuspageComponent: function (componentName, groupId) {
    var request = {
      component: { status: 'operational',
        name: componentName,
        only_show_if_degraded: false,
        showcase: false,
        start_date: '2022-04-01'
      }
    };
    if (!gs.nil(groupId)) {
      request.component.group_id = groupId;
    }
    var path = 'components';
    var rest = new StatuspageRest();
    var response = rest.postREST(path, request);
    var status = response.getStatusCode() || -1;
    if (status == 201) {
      this.sleep(500);
      return JSON.parse(response.getBody());
    } else {
      gs.log("error", "statuspageRequestFailed, status: " + status + ", response: " + response.getBody());
      throw "statuspageRequestFailed";
    }
  },

  /**
   * Get statuspage status - map incident_notification_status to valid statuspage incident status
   * @param {Object} incident object from createIncidentObject, not a gliderecord
   * @return {String} statuspage incident status
   */
  getStatuspageStatus: function (incident) {
    var statuspageStatus = 'investigating';
    switch (incident.incident_notification_status) {
      case 'Restored': statuspageStatus = 'resolved';
        break;
      case 'Initial/Restored': statuspageStatus = 'resolved';
        break;
      case 'Downgrade': statuspageStatus = 'resolved';
        break;
    }
    return statuspageStatus;
  },

  /**
   * Render notification template - use values from incident to render incident html.
   * @param {Object} incident object from createIncidentObject, not a gliderecord
   * @return {String} incdident html
   */
  renderNotificationTemplate: function (incident) {
    switch (incident.incident_notification_status) {
      case 'Initial':
        return this.render(this.statuspageContent.initialTemplate, incident);
      case 'Update':
        return this.render(this.statuspageContent.updateTemplate, incident);
      case 'Restored':
        return this.render(this.statuspageContent.restoredTemplate, incident);
      case 'Initial/Restored':
        return this.render(
          this.statuspageContent.initialRestoredTemplate,
          incident
        );
      case 'Downgrade':
        return this.render(this.statuspageContent.downgradeTemplate, incident);
    }
  },

  /**
   * Get statuspage impact - map incident_priority to valid statuspage impact
   * @param {Object} incident object from createIncidentObject, not a gliderecord
   * @return {String} statuspage impact
   */
  getStatuspageImpact: function (incident) {
    switch (incident.incident_priority) {
      case 'P0':
        return 'critical';
      case 'P1':
        return 'critical';
      case 'P2':
        return 'major';
    }
    return 'minor';
  },

  /**
   * Get incident component ids 
   * @param {Object} incident object from createIncidentObject, not a gliderecord
   * @return {Object} statuspage components that map to incident lobs / brands ({comonentId: 'status',...})
   */
  getIncidentComponents: function (incident) {
    var arrayUtil = new global.ArrayUtil();
    var response = {
      componentIds: [],
      componentStatusMap: {},
      affected: {}
    };
    var componentStatus = 'operational';
    if (arrayUtil.contains(['Initial','Update'], incident.incident_notification_status)) {
        if (incident.incident_priority == 'P2') {
            componentStatus = 'degraded_performance';
        } else {
            componentStatus = 'major_outage';
        }
    }

    // lookup Brands
    var grBrands = new GlideRecord('u_cmdb_ci_brand');
    var grIncidentBrands = grBrands.addJoinQuery('u_m2m_brands_incidents');
    grIncidentBrands.addCondition('u_incident', incident.incident_sys_id);
    grBrands.query();
    var brands = [];
    while (grBrands.next()) {
      brands.push(grBrands.name.toString());
    }

    // lookup LOBs
    var grLob = new GlideRecord('u_cmdb_ci_service_lob');
    var grIncidentLob = grLob.addJoinQuery('u_m2m_line_of_busi_incidents');
    grIncidentLob.addCondition('u_incident', incident.incident_sys_id);
    grLob.query();
    var lobs = [];
    while (grLob.next()) {
      lobs.push(grLob.name.toString());
    }

    // map incidents to statuspage components
    var statuspageComponents = this.getStatuspageComponents();
    var statuspageComponentsNameMap = {};
    statuspageComponents.forEach(function(component){
      statuspageComponentsNameMap[component.group_name + '***' + component.name] = component;
    });
    
    var grStatuspageComponentMapping = new GlideRecord('x_expe2_statuspage_statuspage_components');
    grStatuspageComponentMapping.query();
    while (grStatuspageComponentMapping.next()) {

      var dlMatch = false;
      var incident_dls_configs = grStatuspageComponentMapping.incident_dls.toString().split(',').filter(function(d){
        return !gs.nil(d);
      });
      for (var i = 0; i < incident_dls_configs.length; i++) {
        if (arrayUtil.contains(incident.incident_dls, incident_dls_configs[i])) {
          dlMatch = true;
        }
      }

      var brandMatch = false;
      var brand_configs = grStatuspageComponentMapping.incident_brands.toString().split(',');
      for (var j = 0; j < brand_configs.length; j++) {
        if (arrayUtil.contains(brands, brand_configs[j])) {
          brandMatch = true;
        }
      }

      // var brandMatch = false;
      // d.brands.forEach(function (brand) {
      //   if (arrayUtil.contains(brands, brand)) {
      //     brandMatch = true;
      //   }
      // });
      var lobMatch = false;
      var lob_configs = grStatuspageComponentMapping.incident_lobs.toString().split(',');
      for (var k = 0; k < lob_configs.length; k++) {
        if (arrayUtil.contains(lobs, lob_configs[k])) {
          lobMatch = true;
        }
      }

      // var lobMatch = false;
      // if (arrayUtil.contains(lobs, d.lineOfBusiness)) {
      //   lobMatch = true;
      // }
      var categoryMatch = false;
      if (!gs.nil(grStatuspageComponentMapping.category) && grStatuspageComponentMapping.category.toString() === incident.incident_category) {
        categoryMatch = true;
      }
      var addComponent = false;
      if (brandMatch && lobMatch) {
        addComponent = true;
      } else if (brandMatch && gs.nil(grStatuspageComponentMapping.incident_lobs)) {
        addComponent = true;
      } else if (lobMatch && gs.nil(grStatuspageComponentMapping.incident_brands)) {
        addComponent = true;
      } else if (categoryMatch || dlMatch) {
        addComponent = true;
      }
      if (addComponent) {
        var statuspageGroupName = grStatuspageComponentMapping.component_group.toString();
        var statuspageGroupColumn = grStatuspageComponentMapping.status_grid_group_column.toString();
        var statuspageComponent = statuspageComponentsNameMap[grStatuspageComponentMapping.component_group.toString() + '***' + grStatuspageComponentMapping.component.toString()];
        if (!gs.nil(statuspageComponent)) {
          response.componentStatusMap[statuspageComponent.id] = componentStatus;
          response.componentIds.push(statuspageComponent.id);
          // populate affected object
          if (gs.nil(response.affected[statuspageGroupName])) {
            response.affected[statuspageGroupName] = [];
          }
          if (!gs.nil(statuspageGroupColumn) && !arrayUtil.contains(response.affected[statuspageGroupName], statuspageGroupColumn)) {
            response.affected[statuspageGroupName].push(statuspageGroupColumn);
          }
        }
      }
    }
    return response;
  },

  /**
   * Extracts error message from failed statuspage api request
   * @param {Object} apiResponse object from rest call
   * @return {String} error message
   */
  exctractStatusPageErrorMessage: function (apiResponse) {
    var errorMessage = null;
    try {
      errorMessage = JSON.parse(apiResponse.getBody()).error[0];
    } catch (rawException) {
      this.log('warn',JSON.stringify({
        'message': 'unable to extract error message from api response',
        'response_status_code': apiResponse.getStatusCode(),
        'response_body': apiResponse.getBody(),
        'exception': rawException
      }));
    }
    return errorMessage;
  },

  /**
   * Update (Creates if does not exist) Statuspage Incident
   * @param {Object} incident object from createIncidentObject, not a gliderecord
   * @return {Object} statuspage incident
   */
  updateStatuspageIncident: function (incident, statuspageIncident, incidentComponents, componentStatusUpdates) {
    var request = {
      incident: {
        name: incident.incident_brandprodsvc_affected, status: this.getStatuspageStatus(incident),
        impact_override: this.getStatuspageImpact(incident),
        body: this.renderNotificationTemplate(incident),
        components: componentStatusUpdates,
        component_ids: incidentComponents.componentIds,
        metadata: {
          servicenow: {
            incident_number: incident.incident_number
          },
          componentStatusMap: incidentComponents.componentStatusMap,
          details: incident
        }
      }
    };
    // var requestLogMessage = this.render('event:updateStatuspageIncidentRequest,notificationSysId:{{ incident_notification_sys_id }},incidentNumber:{{ incident_number }},incidentSysID: {{ incident_sys_id }}', incident);
    // var requestLogMessageUpdated = this.render('{{ logMessage }},requestBody:{{ requestBody }}', {
    //   logMessage: requestLogMessage,
    //   requestBody: JSON.stringify(request)
    // });
    var path = gs.nil(statuspageIncident) ? 'incidents' : 'incidents/' + statuspageIncident.id;
    var rest = new StatuspageRest();
    var response;
    if (gs.nil(statuspageIncident)){
        response = rest.postREST(path, request);
    } else {
        response = rest.putREST(path, request);
    }
    var status = response.getStatusCode() || -1;
    if (status == 200 || status == 201) {
      return JSON.parse(response.getBody());
    } else if (status == 422 && exctractStatusPageErrorMessage(response) === 'Incident cannot be updated once set to resolved') {
      this.log('warn',JSON.stringify({
        'message': exctractStatusPageErrorMessage(response),
        'incident_number': incident.incident_number,
        'incident_notification_sys_id': incident. incident_notification_sys_id
      }));
    } else {
      throw "statuspageRequestFailed";
    }
  },

  /**
   * Get Statuspage Component Updates
   * @param {Object} incident object from createIncidentObject, not a gliderecord
   * @param {Object} currentIncidentComponentStatusMap map of current incident component ids to status
   */
  getStatuspageComponentUpdates: function (incident, currentIncidentComponentStatusMap) {
    var statuspageIncidents = this.getStatuspageIncidents().filter(function(d) { return d.status != "resolved"; });
    // add current incident as if it was already updated. Its necessary to update all components in the same request 
    // as the api doesn't support bulk updates outside of incident updates. And updating components individually can
    // cause us to exceed the api rate limit.
    statuspageIncidents.push({ metadata: { componentStatusMap: currentIncidentComponentStatusMap }});
    var incidentsComponentStatusMap = {};
    // loop through incidents, set component status to most impactful state
    for (var i = 0; i < statuspageIncidents.length; i++) {
      var statuspageIncident = statuspageIncidents[i];
      var incidentComponentStatusMap = this.getNestedObject(statuspageIncident, 'metadata.componentStatusMap');
      //  ignore the current incident as returned from the api (use the one added to the list earlier)
      if (incident.incident_number === this.getNestedObject(statuspageIncident, 'metadata.servicenow.incident_number')) {
        continue;
      }  
      if (!gs.nil(incidentComponentStatusMap)) {
        var incidentComponentStatusMapKeys = Object.keys(incidentComponentStatusMap);
        for (var j = 0; j < incidentComponentStatusMapKeys.length; j++) {
          var componentId = incidentComponentStatusMapKeys[j];
          var incidentComponentStatus = incidentComponentStatusMap[componentId];
          // determine if the incident status is worse than the status set in statuspage
          if (incidentComponentStatus === 'major_outage') {
            incidentsComponentStatusMap[componentId] = 'major_outage';
          } else if (incidentComponentStatus === 'degraded_performance' && incidentsComponentStatusMap[componentId] != 'major_outage'){
            incidentsComponentStatusMap[componentId] = 'degraded_performance';
          }
        }
      }
    }
    gs.debug('incidentsComponentStatusMap:' + JSON.stringify(incidentsComponentStatusMap));
    var statuspageComponentsUpdates = {};
    // loop through components, update statuspage object if needed
    var statuspageComponents = this.getStatuspageComponents();
    for (var k = 0; k < statuspageComponents.length; k++) {
      var statuspageComponent = statuspageComponents[k];
      var _incidentComponentStatus = incidentsComponentStatusMap[statuspageComponent.id];
      var newStatus = null;
      if (!gs.nil(_incidentComponentStatus) && statuspageComponent.status != _incidentComponentStatus) {
        newStatus = _incidentComponentStatus;
      } else if (gs.nil(_incidentComponentStatus) && statuspageComponent.status != 'operational'){
        newStatus = 'operational';
      }
      if (!gs.nil(newStatus)) {
        statuspageComponentsUpdates[statuspageComponent.id] = newStatus;
      }
    }
    return statuspageComponentsUpdates;
  },

  /**
   * Get Statuspage Incidents
   * @return {Array} statuspage incidents
   */
  getStatuspageIncidents: function () {
    if (!this.incidentsRetrieved) {
      var rest = new StatuspageRest();
      var response = rest.getREST('incidents');
      var status = response.getStatusCode() || -1;
      if (status == 200) {
        this.allIncidents = JSON.parse(response.getBody());
        this.incidentsRetrieved = true;
      }
    }
    return this.allIncidents;
  },

  /**
   * Get Statuspage Incident
   * @param {String} incidentNumber   ex. INC000000
   * @return {Object} statuspage incident
   */
  getStatuspageIncident: function (incidentNumber) {
    var getNestedObjectfn = this.getNestedObject;
    var incidents = this.getStatuspageIncidents();
    var incident;
    incidents.forEach(function (_incident) {
        if (getNestedObjectfn(_incident, 'metadata.servicenow.incident_number') === incidentNumber) {
          incident = _incident;
        }
      });
    return incident;
  },

  /**
   * Remove paragraph tags
   * @param {String} val string that may contain paragraph html tags
   * @return {string} string with all paragraph html tags removed.
   */
  removeParagraphTags: function (val) {
    return val.replace('<p>', '').replace('</p>', '');
  },

  /**
   * Get Notification DLs
   * @param {Object} notification glide record
   * @return {Array} array of notification dls
   */
  getNotifcationDLs: function (grIncidentNotification) {
    var dl_ids = grIncidentNotification.u_technical_notification_dls.toString().split(",");
    var dls = [];
    for (var i = 0; i < dl_ids.length; i++) {
      var grIncidentNotificationDls = new GlideRecord('u_incident_notification_dls');
      grIncidentNotificationDls.get(dl_ids[i]);
      dls.push(grIncidentNotificationDls.getDisplayValue());
    }
    return dls;
  },


  /**
   * Format Priority
   * @param {Integer} incidentPriority Incident priority (0,1,2,3,...)
   * @return {String} Formatted incident priority string
   */
  formatPriority: function (incidentPriority) {
    if (incidentPriority == 0) {
      return '<b><font color = \'#ff0000\'>***CODE RED INCIDENT SUPPORT PLAN***</b></font>';
    } else {
      return 'P' + incidentPriority;
    }
  },

  /**
   * Format Start Time
   * @param {Integer} incidentNotification u_incident_notifications GlideRecord
   * @return {String} Formatted incident start time
   */
  formatStartTime: function (incidentNotification) {
    // *** May need to add this back in depending on requirements. If so, it will need to be moved to a global script.
    // var tzInstance = gs.getProperty('glide.sys.default.tz'); //get system timezone
    // var tz = Packages.java.util.TimeZone.getTimeZone(tzInstance); //initialize target timezone

    // var gdtStart = new GlideDateTime();
    // gdtStart.setTZ(tz);
    // gdtStart.setValue(incident_start_time);
    // var gdtStartDisplay = gdtStart.getDisplayValue();

    var gdtStartDisplay =
      incidentNotification.u_incident_identified_time.getDisplayValue();

    var startTime = gdtStartDisplay + '';
    startTime = startTime.replace(/:\d\d /, ' ');
    if (this.arrayUtil.contains(['Restored', 'Initial/Restored'],incidentNotification.u_notification_status)) {
      startTime = startTime.replace(/PST/, '');
      startTime = startTime.replace(/PDT/, '');
    }
    return startTime;
  },

  /**
   * Format End Time
   * @param {Integer} incidentNotification u_incident_notifications GlideRecord
   * @return {String} Formatted incident end time
   */
  formatEndTime: function (incidentNotification) {
    // *** May need to add this back in depending on requirements. If so, it will need to be moved to a global script.
    // var tzInstance = gs.getProperty('glide.sys.default.tz'); //get system timezone
    // var tz = Packages.java.util.TimeZone.getTimeZone(tzInstance); //initialize target timezone

    // var gdtEnd = new GlideDateTime();
    // gdtEnd.setTZ(tz);
    // gdtEnd.setValue(incident_end_time);
    // var gdtEndDisplay = gdtEnd.getDisplayValue();

    var gdtEndDisplay =
      incidentNotification.u_incident_determined_time.getDisplayValue();

    var endTime = gdtEndDisplay + '';
    endTime = endTime.replace(/:\d\d /, ' ');
    return endTime;
  },

  /**
   * Format Start / End Time
   * @param {Integer} incidentNotification u_incident_notifications GlideRecord
   * @return {String} Formatted incident start and end time
   */
  formatStartEndTime: function (incidentNotification) {
    var endTime = this.formatEndTime(incidentNotification);
    var startTime = this.formatStartTime(incidentNotification);

    if (endTime == '') {
      return startTime + ' - End Time under investigation';
    } else {
      return startTime + ' to ' + endTime;
    }
  },

  /**
   * Format ETA
   * @param {Integer} incidentNotification u_incident_notifications GlideRecord
   * @return {String} Formatted incident resolution ETA
   */
  formatEta: function (incidentNotification) {
    var formattedEta = 'Under Investigation ';
    var etaTime = incidentNotification.u_end_time__eta_;
    if (!gs.nil(etaTime)) {
      formattedEta = etaTime.getDisplayValue() + '';
      formattedEta = formattedEta.replace(/:\d\d /, ' ');
    }
    return formattedEta;
  },

  /**
   * Render template using {{ mustache }} style templating. Missing keys will not be rendered.
   * @param {String} template 
   * @param {Object} obj map of keys / values to replace in template.
   * @return {String} Rendered template
   */
  render: function (template, obj) {
    var str = template + '';
    Object.keys(obj).forEach(function (key) {
      str = str.replace(
        new RegExp('\\{{\\s+' + key + '\\s+\\}}', 'gi'),
        obj[key]
      );
    });
    return str;
  },

  /**
   * Format Bridge
   * @param {Integer} incidentNotification u_incident_notifications GlideRecord
   * @return {String} Formatted bridge info
   */
  formatBridge: function (incidentNotification) {
    var incident_slack_url = incidentNotification.u_bridge.u_slack_channel_url;
    var bridgeTemplate = '';
    if (!gs.nil(incident_slack_url)) {
      bridgeTemplate =
        '<a href=\'{{ incident_slack_url }}\'>Slack - {{ incident_bridge_name }}</a>&nbsp;&nbsp;&nbsp;';
      bridgeTemplate += '<a href=\'{{ incident_meeting_url }}\'>Zoom Link</a>';
    } else {
      bridgeTemplate = 'No bridge is open at this time.';
    }
    var templateValues = {
      incident_bridge_name: incidentNotification.u_bridge.u_name,
      incident_meeting_url: incidentNotification.u_bridge.u_bluejeans_url,
      incident_slack_url: incident_slack_url
    };
    return this.render(bridgeTemplate, templateValues);
  },

  /**
   * Format Affected
   * @param {Object} affected {"Expedia": ["Lodging",...]}
   * @return {String} Formatted Affected info
   */
  formatAffected: function (incident) {
    var affectedTemplate = '<tr><td>Affected</td><td><ul class="affected-list">{{ affected_items }}</ul></td></tr>';
    var affectedItemTemplate = '<li class="affected-item">{{ group_formatted }} {{ component_list_formatted }}</li>';
    if (Object.keys(incident.affected).length === 0) {
      return '';
    }
    var affectedItems = '';
    var render = this.render;
    var statuspageComponentConfigs = [];
    var grStatuspageComponentConfig = new GlideRecord('x_expe2_statuspage_statuspage_components');
    grStatuspageComponentConfig.query();
    while (grStatuspageComponentConfig.next()) {
      statuspageComponentConfigs.push({
        group: grStatuspageComponentConfig.component_group.toString(),
        group_order: parseInt(grStatuspageComponentConfig.status_grid_group_order.toString()),
        group_row: grStatuspageComponentConfig.status_grid_group_row.toString(),
        group_row_order: parseInt(grStatuspageComponentConfig.status_grid_group_row_order.toString())
      });
    }
    var groupOrder = [];
    var rowOrder = [];
    statuspageComponentConfigs.sort(function(a,b){ return(a.group_order > b.group_order) || (a.group_row_order > b.group_row_order); }).forEach(function(d){
      var arrayUtil = new global.ArrayUtil();
      if (!arrayUtil.contains(groupOrder, d.group)){
        groupOrder.push(d.group);
      }
      if (!arrayUtil.contains(rowOrder, d.group_row)){
        rowOrder.push(d.group_row);
      }
    });
    groupOrder.forEach(function(group){
      if (!gs.nil(incident.affected[group])) {
        var componentList = [];
        var groupFormatted = group;
        var componentListFormatted = '';
        if (incident.affected[group].length > 0) {
          rowOrder.forEach(function(component){
            var arrayUtil = new global.ArrayUtil();
            if (arrayUtil.contains(incident.affected[group], component) && !gs.nil(component)) {
              groupFormatted = group +':';
              componentList.push(component);
            }
          });
          componentListFormatted = componentList.join(', ');
        }
        var templateValues = {
          group_formatted: groupFormatted,
          component_list_formatted: componentListFormatted
        };
        affectedItems+=render(affectedItemTemplate, templateValues);
      }
    });
    var templateValues = {
      affected_items: affectedItems
    };
    return render(affectedTemplate, templateValues);
  },

  /**
   * Update components in statuspage based on config table
   */
  syncStatuspageComponentConfigs: function (dry_run) {
    var has_updates = false;
    var _dry_run = dry_run===true ? dry_run : false;
    var groups = this.getStatuspageGroups();
    var statuspageComponents = this.getStatuspageComponents();
    var statuspageComponentsNameMap = {};
    statuspageComponents.forEach(function(component){
      statuspageComponentsNameMap[component.group_name + '***' + component.name] = component;
    });
    var groupsToAdd = [];
    var grStatuspageComponentConfig = new GlideRecord('x_expe2_statuspage_statuspage_components');
    grStatuspageComponentConfig.query();
    while (grStatuspageComponentConfig.next()) {
      var group_name = grStatuspageComponentConfig.component_group.toString();
      var component_name = grStatuspageComponentConfig.component.toString();
      var component = statuspageComponentsNameMap[group_name + '***' + component_name];
      var group = groups[group_name];
      var groupId = !gs.nil(group) ? group.id : null;
      if (gs.nil(component)) {
        has_updates = true;
        if (_dry_run){
          this.log("info","Component '" + component_name + "' to be created in group '" + group_name + "'.");
        } else {
          this.log("info","Creating component '" + component_name + "' in group '" + group_name + "'.");
          component = this.createStatuspageComponent(component_name, groupId);
        }
      } 
      if (gs.nil(groupId)) {
        if (_dry_run){
          this.log("info","Group '" + group_name + "' to be created.");
        } else {
          this.log("info","Creating group '" + group_name + "'.");
          groupsToAdd.push({group: group_name, componentId: component.id });
        }
        has_updates = true;
      }
    }
    var groupsToAddMap = {};
    groupsToAdd.forEach(function (d) {
      if (gs.nil(groupsToAddMap[d.group])) {
        groupsToAddMap[d.group] = [];
      }
      groupsToAddMap[d.group].push(d.componentId);
    });
    var groupsToAddKeys = Object.keys(groupsToAddMap);
    for (var k = 0; k < groupsToAddKeys.length; k++) {
      var groupName = groupsToAddKeys[k];
      if (!_dry_run){
        var g_params = {
          groupName: groupName,
          data: groupsToAddMap[groupName]
        };
        this.log("info","createStatuspageGroup params:" + JSON.stringify(g_params));
        this.createStatuspageGroup(groupName, groupsToAddMap[groupName]);
      } else {
        this.log("info","Component Group '" + groupName + "' to be created.");
      }
    }
    if (!has_updates){
      this.log("info","No component updates needed.");
    }
  },

  /**
   * @param {Integer} incidentNotification u_incident_notifications GlideRecord
   * @return {Object} incident keys / values used to render template
   */
  createIncidentObject: function (incidentNotification) {

    var grIncident = new GlideRecord('incident');
    grIncident.get(incidentNotification.u_incident_number.sys_id);
    return {
      incident_notification_sys_id: incidentNotification.sys_id.toString(),
      incident_notification_team_name: gs.getProperty('incident.notification.team.name'),
      incident_notification_status: incidentNotification.u_notification_status.toString(),
      servicenow_base_url: gs.getProperty('glide.servlet.uri'),
      incident_sys_id: grIncident.sys_id.toString(),
      incident_number: grIncident.number.toString(),
      incident_priority: this.formatPriority(grIncident.priority),
      booking_impact: this.removeParagraphTags(grIncident.u_booking_impact.getDisplayValue()),
      incident_overview: this.removeParagraphTags(incidentNotification.u_overview.toString()),
      incident_impact: this.removeParagraphTags(incidentNotification.u_cimpact.toString()),
      incident_restoration: this.removeParagraphTags(incidentNotification.u_restoration_info.toString()),
      incident_end_time: this.formatEndTime(incidentNotification),
      incident_start_time: this.formatStartTime(incidentNotification),
      incident_eta_end_time: this.formatEta(incidentNotification),
      incident_start_end_time: this.formatStartEndTime(incidentNotification),
      incident_notifications_survey_link: gs.getProperty('incident_notifications.survey_link'),
      incident_brandprodsvc_affected: incidentNotification.u_brandprodsvc_affected.toString(),
      incident_duration: incidentNotification.u_duration.toString(),
      incident_slack_url: incidentNotification.u_bridge.u_slack_channel_url.toString(),
      incident_bridge_name: incidentNotification.u_bridge.u_name.toString(),
      incident_meeting_url: incidentNotification.u_bridge.u_bluejeans_url.toString(),
      bridge_info: this.formatBridge(incidentNotification),
      incident_downgrade: this.removeParagraphTags(incidentNotification.u_downgrade.toString()),
      incident_technical_info: this.removeParagraphTags(incidentNotification.u_technical_info.toString()),
      incident_past_tech_update_1: incidentNotification.u_past_tech_update_1.toString(),
      incident_past_tech_update_2: incidentNotification.u_past_tech_update_2.toString(),
      incident_category: grIncident.category.toString(),
      incident_dls: this.getNotifcationDLs(incidentNotification)
    };
  },

  /**
   * Sync Notification to Statuspage
   * @param (Object) u_incident_notification GlideRecord
   */
  processRecord: function (incidentNotification, attempt) {
    var updatedAttempt = attempt + 1;
    try {
      var incident = this.createIncidentObject(incidentNotification);
      var incidentComponents = this.getIncidentComponents(incident);
      incident.affected = incidentComponents["affected"];
      incident.affected_html = this.formatAffected(incident);
      var statuspageIncident = this.getStatuspageIncident(incident.incident_number);
      // don't create incident if no componentIds are mapped, but update if it already exists
      if (incidentComponents.componentIds.length === 0 && gs.nil(statuspageIncident)) {
        var logMessage = this.render('event:unableToProcessNotification,notificationSysId:{{ incident_notification_sys_id }},incidentNumber:{{ incident_number }},incidentSysID: {{ incident_sys_id }}', incident);
        this.log("info",logMessage);
        return;
      }
      var statuspageComponentUpdates = this.getStatuspageComponentUpdates(incident, incidentComponents.componentStatusMap);
      this.updateStatuspageIncident(incident, statuspageIncident, incidentComponents, statuspageComponentUpdates);
      
    }
    catch (rawException) {
      var errorLogMessage = this.render('event:processRecordError,message:{{ exception }},notificationSysId:{{ notificationSysId }},incidentSysID: {{ incidentSysId }},attempt:{{ attempt }}', 
      { exception: JSON.stringify(rawException), 
        notificationSysId: incidentNotification.sys_id,
        incidentSysId: incidentNotification.u_incident_number.sys_id,
        attempt: updatedAttempt });
      gs.error(errorLogMessage);
      if (updatedAttempt <= this.maxRetryCount) { 
        var so = new global.ScheduleOnce();
        so.script = this.render("var statuspageSync = new x_expe2_statuspage.StatuspageSync(); statuspageSync.retryProcessRecord('{{ notificationSysId }}', {{ attempt }});",
          { notificationSysId: incidentNotification.sys_id.toString(),
            attempt: updatedAttempt });
        so.setAsSeconds(10 * updatedAttempt);
        so.schedule();
      } else {
        try {
          var emf = new global.EMF();
          var eventType = 'ServiceNow unable to update statuspage';
          var summary = this.render('Failed to update Statuspage for incident [{{ incident_number }}] - {{ incident_notification_status }}: {{ incident_brandprodsvc_affected }}',{
            incident_number: incidentNotification.u_incident_number.getDisplayValue(),
            incident_notification_status: incidentNotification.u_notification_status.toString(),
            incident_brandprodsvc_affected: incidentNotification.u_brandprodsvc_affected.toString()
          });
          var isCritical = true;
          var emfContent = emf.getSNEventContent(eventType, summary, isCritical);
          this.log('info','Sending to EMF: ' + JSON.stringify(emfContent));
          var emfResponse = emf.sendAlert(emfContent);
          this.log('info',this.render('EMF Response {{ statusCode }} {{ responseBody }}',{
            statusCode: emfResponse.getStatusCode(),
            responseBody: emfResponse.getBody()
          }));
        } catch(emfException){
          this.log('error','failed to send to EMF: ' + emfException);
        }
        
      }
    }
  },
  retryProcessRecord: function (incidentNotificationSysId, attempt) {
    try {
      var logMessage = this.render('event:retryProcessRecord,attempt:{{ attempt }},notificationSysId:{{ notificationSysId }}', 
        { attempt: attempt, 
          notificationSysId: incidentNotificationSysId });
      this.log('info',logMessage);
      var grIncidentNotification = new GlideRecord('u_incident_notifications');
      grIncidentNotification.get(incidentNotificationSysId);
      this.processRecord(grIncidentNotification, attempt);
    }
    catch (rawException) {
      var errorLogMessage = this.render('event:retryProcessRecordError,messaege:{{ exception }},notificationSysId:{{ notificationSysId }}', 
        { exception: JSON.stringify(rawException), 
          notificationSysId: incidentNotificationSysId });
      gs.error(errorLogMessage);
    }
  },
  type: 'StatuspageSync'
};
