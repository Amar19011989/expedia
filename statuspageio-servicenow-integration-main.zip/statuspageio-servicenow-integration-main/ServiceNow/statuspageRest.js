var StatuspageRest = Class.create();

StatuspageRest.prototype = {
	initialize: function () {
		this.JSON = new global.JSON();

		//API properties
		this.statusPageApiKey = gs.getProperty('x_expe2_statuspage.api_key');
		this.statuspagePageId = gs.getProperty('x_expe2_statuspage.page_id');
		this.logLevels = gs.getProperty('x_expe2_statuspage.log_levels').split(',') || [];
		this.endpoint = 'https://api.statuspage.io/v1/pages/' + this.statuspagePageId + '/';
	},

	/**
		 * Render template using {{ mustache }} style templating. Missing keys will not be rendered.
		 * @param {String} template 
	 * @param {Object} obj map of keys / values to replace in template.
		 * @return {String} Rendered template
		 */
	render: function (template, obj) {
		var str = template + '';
		Object.keys(obj).forEach(function (key) {
		str = str.replace(
			new RegExp('\\{{\\s+' + key + '\\s+\\}}', 'gi'),
			obj[key]
		);
		});
		return str;
	},


	/**
	 * Log if level is configured
	 * @param {String} level log level (info, error)
	 * @param {String} msg log message
	 */
	log: function(level, msg) {
		var arrayUtil = new global.ArrayUtil();
		if (arrayUtil.contains(this.logLevels, level)) {
			gs[level](msg);
		}
	},

	/**
	 * Put message body to specific path
	 * @param {String} endpoint path
	 * @param {String} request body
	 * @param (String) client
	 * @param (String) client URL
	 * @return {RESTResponse} put response
	 */
	putREST: function (path, body) {
		try {
			var bodyJSON = this.JSON.encode(body);
			
			var restMessage = new sn_ws.RESTMessageV2();
			restMessage.setHttpMethod('put');
			restMessage.setRequestHeader('Authorization', 'OAuth ' + this.statusPageApiKey);
			restMessage.setRequestHeader('Content-Type', 'application/json');
			restMessage.setEndpoint(this.endpoint + path);
			restMessage.setRequestBody(bodyJSON);
			var requestLogMessage = this.render('event:putRestRequest,endpoint:{{ endpoint }},requestBody:{{ requestBody }}', {
				endpoint: restMessage.getEndpoint(),
				requestBody: bodyJSON
			});
			this.log('info',requestLogMessage);
			var response = restMessage.execute();
			var responselogMessage = this.render('event:putRestResponse,endpoint:{{ endpoint }},statusCode:{{ statusCode }},responseBody:{{ responseBody }}', {
				endpoint: restMessage.getEndpoint(),
				statusCode: response.getStatusCode(),
				responseBody: response.getBody()
			});
			this.log('info',responselogMessage);	
			return response;

		} catch (ex) {
			gs.error('event:putRestResponseError,message:' + JSON.stringify(ex));
		}
	},


	/**
	 * Post message body to specific path
	 * @param {String} endpoint path
	 * @param {String} request body
	 * @param (String) requester
	 * @param (String) client
	 * @param (String) client URL
	 * @return {RESTResponse} post response
	 */
	postREST: function (path, body) {
		try {

			var bodyJSON = this.JSON.encode(body);

			var restMessage = new sn_ws.RESTMessageV2();
			restMessage.setHttpMethod('post');
			restMessage.setRequestHeader('Authorization', 'OAuth ' + this.statusPageApiKey);
			restMessage.setRequestHeader('Content-Type', 'application/json');
			restMessage.setEndpoint(this.endpoint + path);
			restMessage.setRequestBody(bodyJSON);

			var requestLogMessage = this.render('event:postRestRequest,endpoint:{{ endpoint }},requestBody:{{ requestBody }}', {
				endpoint: restMessage.getEndpoint(),
				requestBody: bodyJSON
			});
			this.log('info',requestLogMessage);
			var response = restMessage.execute();
			var responselogMessage = this.render('event:postRestResponse,endpoint:{{ endpoint }},statusCode:{{ statusCode }},responseBody:{{ responseBody }}', {
				endpoint: restMessage.getEndpoint(),
				statusCode: response.getStatusCode(),
				responseBody: response.getBody()
			});
			this.log('info',responselogMessage);	
			return response;

		} catch (ex) {
			gs.error('event:postRestResponseError,message:' + JSON.stringify(ex));
		} 
	},

	/**
	 * patch message body to specific path
	 * @param {String} endpoint path
	 * @param {String} request body
	 * @param (String) requester
	 * @param (String) client
	 * @param (String) client URL
	 * @return {RESTResponse} patch response
	 */
	 patchREST: function (path, body) {
		try {
			var bodyJSON = this.JSON.encode(body);

			var restMessage = new sn_ws.RESTMessageV2();
			restMessage.setHttpMethod('patch');
			restMessage.setRequestHeader('Authorization', 'OAuth ' + this.statusPageApiKey);
			restMessage.setRequestHeader('Content-Type', 'application/json');
			restMessage.setEndpoint(this.endpoint + path);
			restMessage.setRequestBody(bodyJSON);

			var requestLogMessage = this.render('event:patchRestRequest,endpoint:{{ endpoint }},requestBody:{{ requestBody }}', {
				endpoint: restMessage.getEndpoint(),
				requestBody: bodyJSON
			});
			this.log('info',requestLogMessage);

			var response = restMessage.execute();
			var responselogMessage = this.render('event:patchRestResponse,endpoint:{{ endpoint }},statusCode:{{ statusCode }},responseBody:{{ responseBody }}', {
				endpoint: restMessage.getEndpoint(),
				statusCode: response.getStatusCode(),
				responseBody: response.getBody()
			});
			this.log('info',responselogMessage);	
			return response;
		} catch (ex) {
			gs.error('event:patchRestResponseError,message:' + JSON.stringify(ex));
		} 
	},


	/**
	 * Get query with parameters
	 * @param {String} path
	 * @param {Object} message parameters
	 * @return {RESTResponse} get response
	 */
	getREST: function (path, params) {
		// Send web request via Statuspage's REST API

		// Configure REST message
		try {
			var restMessage = new sn_ws.RESTMessageV2();
			restMessage.setHttpMethod('get');
			restMessage.setRequestHeader('Authorization', 'OAuth ' + this.statusPageApiKey);
			restMessage.setRequestHeader('Content-Type', 'application/json');
			restMessage.setEndpoint(this.endpoint + path);
			var requestParamsLog = '';
			if (!gs.nil(params)) {
				Object.keys(params).forEach(function(param){
					restMessage.setStringParameter(param, params[param]);
					requestParamsLog += param + "=" + params[param];
				});
			}
			var requestLogMessage = this.render('event:getRestRequest,endpoint:{{ endpoint }},params:{{ requestParams }}', {
				endpoint: restMessage.getEndpoint(),
				requestParams: requestParamsLog
			});
			this.log('info',requestLogMessage);

			var response = restMessage.execute();
			var responselogMessage = this.render('event:getRestResponse,endpoint:{{ endpoint }},statusCode:{{ statusCode }},responseBody:{{ responseBody }}', {
				endpoint: restMessage.getEndpoint(),
				statusCode: response.getStatusCode(),
				responseBody: response.getBody()
			});
			this.log('info',responselogMessage);	
			return response;

		} catch (ex) {
			gs.error('event:getRestResponseError,message:' + JSON.stringify(ex));
		}

	},


	/**
	 * Delete the entry
	 * @param {String} endpoint path
	 * @return {RESTResponse} delete response
	 */
	deleteREST: function (path) {
		// Send web request via Statuspage's REST API

		// Configure REST message
		var response;
		try {
			var restMessage = new sn_ws.RESTMessageV2();
			restMessage.setHttpMethod('delete');
			restMessage.setRequestHeader('Authorization', 'OAuth ' + this.statusPageApiKey);
			restMessage.setRequestHeader('Content-Type', 'application/json');
			restMessage.setEndpoint(this.endpoint + path);

			var requestLogMessage = this.render('event:deleteRestRequest,endpoint:{{ endpoint }},params:{{ requestParams }}', {
				endpoint: restMessage.getEndpoint()
			});
			this.log('info',requestLogMessage);
			response = restMessage.execute();
			var responselogMessage = this.render('event:deleteRestResponse,endpoint:{{ endpoint }},statusCode:{{ statusCode }},responseBody:{{ responseBody }}', {
				endpoint: restMessage.getEndpoint(),
				statusCode: response.getStatusCode(),
				responseBody: response.getBody()
			});
			this.log('info',responselogMessage);	
			return response;
		} catch (ex) {
			gs.error('event:deleteRestResponseError,message:' + JSON.stringify(ex));
		}
	},

	type: 'StatuspageRest'
};
