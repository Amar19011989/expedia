const fs = require('fs');
const template = require('lodash.template');
const templateSettings = require('lodash.templatesettings');

templateSettings.interpolate = /{{([\s\S]+?)}}/g;

var compiledStatuspageContentJsTemplate = template(fs.readFileSync('statuspageContentJs.template', 'utf8'));

fs.writeFileSync('StatuspageContent.js', compiledStatuspageContentJsTemplate({
    'restored_template': JSON.stringify(fs.readFileSync('restored.template', 'utf8')),
    'initial_restored_template': JSON.stringify(fs.readFileSync('initialRestored.template', 'utf8')),
    'initial_template': JSON.stringify(fs.readFileSync('initial.template', 'utf8')),
    'downgrade_template': JSON.stringify(fs.readFileSync('downgrade.template', 'utf8')),
    'update_template': JSON.stringify(fs.readFileSync('update.template', 'utf8'))
}))

