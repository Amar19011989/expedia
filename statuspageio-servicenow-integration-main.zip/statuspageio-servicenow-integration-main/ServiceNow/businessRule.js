// business rule to trigger statuspage sync
(function executeRule(current, previous /*null when async*/) {
	var statuspageSync = new StatuspageSync();
	statuspageSync.processRecord(current, 0);
})(current, previous);