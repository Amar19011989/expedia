// var incidents = ['INC6855171'];
// var notificationTypeToProcess = 'Update';
// incidents.forEach(function(incident_number){
//     var incidentNotificationGR = new GlideRecord('u_incident_notifications');
//     incidentNotificationGR.addQuery('u_incident_number.number', incident_number);
//     incidentNotificationGR.query();
//     while(incidentNotificationGR.next()) {
//         gs.info(incidentNotificationGR.u_notification_status);
//         if (incidentNotificationGR.u_notification_status == notificationTypeToProcess) {
//             var statuspageSync = new x_expe2_statuspage.StatuspageSync();
//             statuspageSync.processRecord(incidentNotificationGR, 0);
//         }
//     }
// });

// var incident = {
//     "affected": {
//         "Corporate Office": []
//     },
//     "bridge_info": "<a href='https://expedia.slack.com/messages/C8H104UCC'>Slack - Golden Gate</a>&nbsp;&nbsp;&nbsp;<a href='https://expedia.zoom.us/j/97261186344?pwd=dXFUd2NQWmozM3Q2cllUV0ZvY1l6QT09'>Zoom Link</a>",
//     "affectedHtml": "<tr><td>Affected</td><td><ul></ul></td></tr>",
//     "booking_impact": "Minor Booking Impact",
//     "incident_impact": "Test Office Outage Impact Update",
//     "incident_number": "INC6495877",
//     "incident_sys_id": "c1bba88b87b6d110b2e1c88e8bbb3586",
//     "incident_category": "office",
//     "incident_duration": "",
//     "incident_end_time": "",
//     "incident_overview": "Test Office Outage Overview Update2",
//     "incident_priority": "P1",
//     "incident_downgrade": "",
//     "incident_slack_url": "https://expedia.slack.com/messages/C8H104UCC",
//     "incident_start_time": "10-31-2022 12:39 PM",
//     "servicenow_base_url": "https://expediadev.service-now.com/",
//     "incident_bridge_name": "Golden Gate",
//     "incident_meeting_url": "https://expedia.zoom.us/j/97261186344?pwd=dXFUd2NQWmozM3Q2cllUV0ZvY1l6QT09",
//     "incident_restoration": "",
//     "incident_eta_end_time": "Under Investigation ",
//     "incident_start_end_time": "10-31-2022 12:39 PM - End Time under investigation",
//     "incident_technical_info": "Update 2",
//     "incident_past_tech_update_1": "<p>10-31-2022 1:17:59 PM - Update</p>",
//     "incident_past_tech_update_2": "<p>10-31-2022 12:43:59 PM - Initial Information: Test Office Outage Additional Info</p>",
//     "incident_notification_status": "Update",
//     "incident_brandprodsvc_affected": "Test Office Outage",
//     "incident_notification_team_name": "NOC Outage Notification",
//     "incident_notifications_survey_link": "nav_to.do?uri=assessment_take2.do%3Fsysparm_assessable_type=bd75fb492baade407c8e764317da1536"
// }

// var statuspageSync = new x_expe2_statuspage.StatuspageSync();

// gs.info(statuspageSync.formatAffected(incident))


// (function(outputs, steps, stepResult, assertEqual) {
//     gs.setProperty('x_pd_integration.sn2pd_mapping', 'Assignment Groups map to PagerDuty');
// 	var prop = gs.getProperty('x_pd_integration.sn2pd_mapping');
// 	stepResult.setOutputMessage("Successfully set sn2pd_mapping to '"+prop+"'");
// 	return true;

// })(outputs, steps, stepResult, assertEqual);


// var incidentNotificationGR = new GlideRecord('u_incident_notifications');

// A - incident #1 opened list of components set to major outage
//     - components should be set to major outage
// B - incident #1 updated with additional components
//     - added components should be set to major outage
// C - incident #1 updated with fewer components
//     - removed components should be set to operational
// D - incident #1 updated with additional components and downgraded to degraded pereformance
//     - existing and new components should be set to deraded performance
// E - incident #1 updated with fewer components and upgraded to major outage
//     - removed components shold be set to operational, remaining components should be set to major outage
// F - incident #2 opened with some overlapping components set to degraded performancee
//     - overlapping components should remain set to major outage, non-overelapping components should be set to degraded performance
// G - incident #2 update
//     - component status should not change
// H - incident #1 resolved
//     - overlapping components should be set to degraded performance, non-overelapping components should be set to operational
// I - incident #2 resolved
//     - all components should be set to operational

// INC6855171
// A
// B: Add Vacation Rentals to INC6855171, then run again
// C: Remove Vacation Rentals on INC6855171, then run again
// D: Add Vacation Rentals to INC6855171, set to P2, then run again
// E: Remove Vacation Rentals on INC6855171, set to P1, then run again

// https://expediadev2.service-now.com/nav_to.do?uri=%2Fu_incident_notifications.do%3Fsys_id%3D6602c3c51b83d91461db8663cc4bcb25%26sysparm_record_target%3Du_incident_notifications%26sysparm_record_row%3D2%26sysparm_record_rows%3D2%26sysparm_record_list%3Du_incident_number%253Df7308b4197475d50784cbb4e6253af8e%255EORDERBYDESCsys_created_on%255EORDERBYsys_id
var notificationSysId = '6602c3c51b83d91461db8663cc4bcb25';
var incidentNotificationGR = new GlideRecord('u_incident_notifications');
incidentNotificationGR.addQuery('sys_id', notificationSysId);
incidentNotificationGR.query();
while(incidentNotificationGR.next()) {
    incidentNotificationGR.u_technical_notification_dls.forEach(function(d){
        gs.info(d);
    })
}


var notificationSysId = 'db32e7b21ba4a994835c8736604bcb70';
var incidentNotificationGR = new GlideRecord('u_incident_notifications');
incidentNotificationGR.addQuery('sys_id', notificationSysId);
incidentNotificationGR.query();
while(incidentNotificationGR.next()) {
    gs.info(incidentNotificationGR.u_notification_status);
    var statuspageSync = new x_expe2_statuspage.StatuspageSync();
    statuspageSync.processRecord(incidentNotificationGR, 0);
}

// INC6882673
// F: Initial

var notificationSysId = 'd2a3e219db85e990afb23ec8f496194f';
var incidentNotificationGR = new GlideRecord('u_incident_notifications');
incidentNotificationGR.addQuery('sys_id', notificationSysId);
incidentNotificationGR.query();
while(incidentNotificationGR.next()) {
    gs.info(incidentNotificationGR.u_notification_status);
    var statuspageSync = new x_expe2_statuspage.StatuspageSync();
    statuspageSync.processRecord(incidentNotificationGR, 0);
}

// INC6882673
// G: Update

var notificationSysId = '9b476211db09e990afb23ec8f4961950';
var incidentNotificationGR = new GlideRecord('u_incident_notifications');
incidentNotificationGR.addQuery('sys_id', notificationSysId);
incidentNotificationGR.query();
while(incidentNotificationGR.next()) {
    gs.info(incidentNotificationGR.u_notification_status);
    var statuspageSync = new x_expe2_statuspage.StatuspageSync();
    statuspageSync.processRecord(incidentNotificationGR, 0);
}


// INC6855171
// H: resolved

var notificationSysId = '2892abb61ba4a994835c8736604bcb1b';
var incidentNotificationGR = new GlideRecord('u_incident_notifications');
incidentNotificationGR.addQuery('sys_id', notificationSysId);
incidentNotificationGR.query();
while(incidentNotificationGR.next()) {
    gs.info(incidentNotificationGR.u_notification_status);
    var statuspageSync = new x_expe2_statuspage.StatuspageSync();
    statuspageSync.processRecord(incidentNotificationGR, 0);
}

// INC6882673
// I: Update

var notificationSysId = '5dcf62d1dbc9e990afb23ec8f496190a';
var incidentNotificationGR = new GlideRecord('u_incident_notifications');
incidentNotificationGR.addQuery('sys_id', notificationSysId);
incidentNotificationGR.query();
while(incidentNotificationGR.next()) {
    gs.info(incidentNotificationGR.u_notification_status);
    var statuspageSync = new x_expe2_statuspage.StatuspageSync();
    statuspageSync.processRecord(incidentNotificationGR, 0);
}


var statuspageSync = new x_expe2_statuspage.StatuspageSync();
statuspageSync.syncStatuspageComponentConfigs(true);



var notificationSysId = '8ad165421bcd1998835c8736604bcbe3';
var incidentNotificationGR = new GlideRecord('u_incident_notifications');
incidentNotificationGR.addQuery('sys_id', notificationSysId);
incidentNotificationGR.query();
while(incidentNotificationGR.next()) {
    gs.info(incidentNotificationGR.u_notification_status);
    var statuspageSync = new x_expe2_statuspage.StatuspageSync();
    statuspageSync.processRecord(incidentNotificationGR, 0);
}