const fs = require('fs');


const component_configs = fs.readFileSync('x_expe2_statuspage_statuspage_components.json', 'utf8')

const history = fs.readFileSync('history.json', 'utf8')




// d3.groups(component_mapping.records, d=>d.status_grid_group)
//   .sort(([, a], [, b]) => d3.ascending(a, b))
//   .sort((a, b)=>d3.ascending(parseInt(d.status_grid_group_order)=>parseInt(d.status_grid_group_order))) 

//             .key(function (d) { return d.status_grid_group; })
//             .key(function (d) { return d.component_group; })
//             .key(function (d) { return d.component; })
//             .entries(component_mapping);

// d3.groups(component_mapping, d=>d.status_grid_group)            
// d3.groupSort(component_mapping.records, d=>d3.max(parseInt(d.status_grid_group_order)), d=>d.status_grid_group)

// d3.groupSort(component_mapping.records, g => d3.median(g, d => parseInt(d.status_grid_group_order)), d => d.status_grid_group)

// const sorted_components = component_mapping.records.sort((a, b) => 
//     d3.ascending(parseInt(a.status_grid_group_order), parseInt(b.status_grid_group_order)) ||
//     d3.ascending(parseInt(a.status_grid_group_row_order), parseInt(b.status_grid_group_row_order)))






// d3.groups(sorted_components, d=>d.status_grid_group + "_" + d.status_grid_group_row);


// const status_grid_groups = d3.groups(component_mapping.records, d=>d.status_grid_group)
//   .sort((a, b)=>d3.ascending(parseInt(a[1].status_grid_group_order),parseInt(b[1].status_grid_group_order)))

// const status_grid_rows = d3.groups(status_grid_groups[0][1], d=>d.status_grid_group_row)
// .sort((a, b)=>d3.ascending(parseInt(a[1].status_grid_group_row_order),parseInt(b[1].status_grid_group_row_order)))







const components = history.components.filter(d=>!d.group);
const component_group_map = d3.group(history.components.filter(d=>d.group), d=>d.name);

const component_status_map = new Map();
const component_group_status_map = new Map();
for (var i = 0; i < components.length; i++) {
    const group_id = components[i].group_id;
    const component_status = components[i].status;
    component_status_map.set(group_id + "_" + components[i].id, component_status);
    if (component_status === "major_outage") {
        component_group_status_map.set(group_id, component_status);
    } else if (component_status === "degraded_performance" && component_group_status_map.get(group_id) != "major_outage") {
        component_group_status_map.set(group_id, component_status);
    } else if (!component_group_status_map.has(group_id)){
        component_group_status_map.set(group_id, component_status);
    }
}

const status_grid_columns = ["Lodging","Flights","Cars","Packages","Activities","Cruise","Other"];

const sorted_component_configs = component_configs.records.sort((a, b) => 
  d3.ascending(parseInt(a.status_grid_group_order), parseInt(b.status_grid_group_order)) ||
  d3.ascending(parseInt(a.status_grid_group_row_order), parseInt(b.status_grid_group_row_order)))

function test(val){
    console.log(val);
    return "foo";
}
const status_grid_groups = d3.groups(sorted_component_configs, d=>d.status_grid_group, d=>d.status_grid_group_row)
  .sort((a, b)=>d3.ascending(parseInt(a[1].status_grid_group_order),parseInt(b[1].status_grid_group_order)))
  .map(d=>{
    return {
        status_grid_group: d[0],
        status_grid_group_rows: d[1],
        status_grid_group_lob_status: test(d[1])
    }
  })
