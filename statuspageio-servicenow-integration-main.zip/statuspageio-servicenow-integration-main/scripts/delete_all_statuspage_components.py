import requests
import os
import sys
import time

STATUSPAGE_ID = os.environ.get("STATUSPAGE_ID")
STATUSPAGE_API_KEY = os.environ.get("STATUSPAGE_API_KEY")

def get_components():
	page = 0
	more = True
	components = []
	while more:
		url = f"https://api.statuspage.io/v1/pages/{STATUSPAGE_ID}/components?per_page=100"
		if page > 0:
			url = f"{url}&page={page}"
		print(url)
		response = requests.get(url, headers={"Authorization": f"OAuth {STATUSPAGE_API_KEY}"})
		if response.ok:
			components.extend(response.json())
			if len(response.json()) < 100:
				more = False
		else:
			print(f"Request failed {response.status_code}: {response.text}")
			sys.exit()
		page = page + 1
	return components

def delete_component(component_id, group=False):
	url = f"https://api.statuspage.io/v1/pages/{STATUSPAGE_ID}/components/{component_id}"
	if group:
		url = f"https://api.statuspage.io/v1/pages/{STATUSPAGE_ID}/component-groups/{component_id}"
	print(url)
	response = requests.delete(url, headers={"Authorization": f"OAuth {STATUSPAGE_API_KEY}"})
	if response.ok:
		# API limit is 120 requests per minute
		time.sleep(0.25)
	else:
		print(f"Request failed {response.status_code}: {response.text}")
		sys.exit()

components = get_components()
for component in components:
	# 		Groups are automatically deleted when they no longer have any components associated to 
	# 	them, so its unecessary to delete them.
	if not component["group"]:
		delete_component(component["id"])
