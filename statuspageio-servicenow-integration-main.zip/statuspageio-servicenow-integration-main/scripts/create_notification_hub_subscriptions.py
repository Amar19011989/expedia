import os
import json
import requests
from requests.auth import HTTPBasicAuth
from copy import deepcopy
import sys

NOTIFICATION_HUB_USERNAME=os.environ.get("NOTIFICATION_HUB_USERNAME")
NOTIFICATION_HUB_PASSWORD=os.environ.get("NOTIFICATION_HUB_PASSWORD")
STATUSPAGE_ID=os.environ.get("STATUSPAGE_ID")

access_token = None

def get_access_token():
    global access_token
    if not access_token:
        token_url = "https://api.us-west-2.prod.notificationhub.expedia.biz/v1/token"
        tonen_response = requests.post(token_url, data="{}", auth=HTTPBasicAuth(NOTIFICATION_HUB_USERNAME, NOTIFICATION_HUB_PASSWORD))
        access_token = tonen_response.json()["access_token"]
    return access_token

def get_statuspage_subscriptions():
    url = f"https://api.us-west-2.prod.notificationhub.expedia.biz/v1/subscription?Application=statuspage_{STATUSPAGE_ID}"
    response = requests.get(url, headers={"Authorization": f"Bearer {get_access_token()}"})
    return [i for i in response.json() if i["Enabled"] == "True"]


def update_statuspage_subscription(subscription_id, updated_subscription):
    print("updated_subscription", updated_subscription)
    url = f"https://api.us-west-2.prod.notificationhub.expedia.biz/v1/subscription?SubscriptionId={subscription_id}"
    
    response = requests.put(url, json=updated_subscription, headers={"Authorization": f"Bearer {get_access_token()}"})
    if response.ok:
        print("Updated Subscription: ", updated_subscription)
    else:
        print(f"Failed to update subscription: {json.dumps(updated_subscription)}, status_code: {response.status_code}, response: {response.text}, url: {url}" )
        sys.exit()

def create_statuspage_subscription(subscription):
    url = f"https://api.us-west-2.prod.notificationhub.expedia.biz/v1/subscription"
    response = requests.post(url, json=subscription, headers={"Authorization": f"Bearer {get_access_token()}"})
    if response.ok:
        print("Created Subscription: ", subscription)
    else:
        print(f"Failed to create subscription: {json.dumps(subscription)}, status_code: {response.status_code}, response: {response.text}, url: {url}" )
        sys.exit()

def get_user_groups():
    url = f"https://api.us-west-2.prod.notificationhub.expedia.biz/v1/user/groups"
    response = requests.get(url, headers={"Authorization": f"Bearer {get_access_token()}"})
    if response.ok:
        print("User Groups ", response.json())
    else:
        print(f"Failed to get user groups: status_code: {response.status_code}, response: {response.text}, url: {url}, access_token: {get_access_token()}" )
        
# def update_subscriptions(original_component_id, new_component_id):
#     statuspage_subscriptions = get_statuspage_subscriptions()
#     with open("before.json","w") as before:
#         b=before.write(json.dumps(statuspage_subscriptions,indent=4))
#     # statuspage_subscriptions = [i for i in  statuspage_subscriptions if i["SubscriptionId"] == "bf1795e7-92c5-43df-ac0c-a1523317a8d2"]
#     print(statuspage_subscriptions)
#     for statuspage_subscription in statuspage_subscriptions:
#         updated_subscription = deepcopy(statuspage_subscription)
#         updated_subscription["DispatchConfiguration"] = []
#         update_subscription = False
#         for disp_config in statuspage_subscription["DispatchConfiguration"]:
#             updated_disp_config = deepcopy(disp_config)
#             original_filter_criteria_snippet = f"id =='{original_component_id}'"
#             replacement_filter_criteria_snippet = f"id =='{original_component_id}' || id =='{new_component_id}'"
#             if original_filter_criteria_snippet in disp_config["FilterCriteria"] and new_component_id not in disp_config["FilterCriteria"]:
#                 updated_disp_config["FilterCriteria"] = disp_config["FilterCriteria"].replace(original_filter_criteria_snippet, replacement_filter_criteria_snippet)
#                 update_subscription = True
#             updated_subscription["DispatchConfiguration"].append(updated_disp_config)
#         if update_subscription:
#             subscription_id = updated_subscription["SubscriptionId"]
#             del updated_subscription["SubscriptionId"]
#             update_statuspage_subscription(subscription_id, updated_subscription)



# with open("after.json","w") as after:
#     b=after.write(json.dumps(get_statuspage_subscriptions(),indent=4))
# get_user_groups()



# - Hotels.com added Insurance
# - Vrbo added Insurance
# - Contact Center added VA/VAP
# - Internal Tools and Services added ServiceNow, Splunk, Salesforce, Jira, Confluence, Slack, Zoom, EGDP

# https://manage.statuspage.io/pages/htpwsxgm14yp/components/trzh3qj62pbq/edit

# https://manage.statuspage.io/pages/htpwsxgm14yp/components/xz79y7l9f2t3/edit

users_to_add = ["bmiller"]

for user in users_to_add:
    new_subscription = {
        "Application": "statuspage_1m1l8xn73psr",
        "Enabled": "True",
        "ConfigurationSource": "statuspage",
        "DispatchConfiguration": [
            {
                "type": "email",
                "targets": [
                    f"{user}@expediagroup.com"
                ],
                "FilterCriteria": "sourceId == 'statuspage' && details.app_name == 'statuspage_1m1l8xn73psr'",
                "options": {},
                "group_by": [],
                "schedule": None
            }
        ],
        "GroupName": "user",
        "UserName": f"{user}@expediagroup.com",
        "Name": "",
        "Description": ""
    }
    create_statuspage_subscription(new_subscription)